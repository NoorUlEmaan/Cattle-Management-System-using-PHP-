<?php 
include 'db.php';


//System Settings
define('NAME_', 'COW FARM');
define('NAME_X', 'FARM MANAGEMENT SYSTEM');


ob_start();
session_start();